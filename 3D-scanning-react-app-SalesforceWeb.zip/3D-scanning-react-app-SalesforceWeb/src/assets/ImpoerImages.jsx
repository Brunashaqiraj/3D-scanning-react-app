import Sezondekor from "./sezon-dekor.png";
import Infissi from "./LF-Infissi-Logo-1.png";
import Newmedia from "./new-media.png";
import Brianza from "./Brianza-Dent-Logo.png";
import Parlamanti from "./Parlamenti-Logo-1.png";
import Pierre from "./Pierre-Cardin.png";
import RealEstate from "./Real-Estate-Logo.png";
import PierreGallery from "./Pierr-Cardin-gallary.png";
import Mail from "./Mail.png";
import Phone from "./Phone.png";
import AboutUs from "./about_us.jpg";
import OurVision from "./our_vision.jpg";
import Benefits from "./benefits_backgroung.jpg";
import BlacklLogo from "./black-logo.svg";
import BannerImg from "./banner_image.jpg";

export const images = {
  Sezondekor,
  Infissi,
  Newmedia,
  Brianza,
  Parlamanti,
  Pierre,
  RealEstate,
  PierreGallery,
  Mail,
  Phone,
  AboutUs,
  OurVision,
  Benefits,
  BlacklLogo,
  BannerImg,
};
