import CardOne from './Svg/CardOne.jpg'
import CardTwo from "./Svg/CardTwo.jpg"
import CardThree from "./Svg/CardThree.jpg";
import CardFour from "./Svg/CardFour.jpg";
import CardFive from "./Svg/CardFive.jpg";
import CardSix from "./Svg/CardSix.jpg";
import CardSeven  from "./Svg/CardSeven.jpg";
import CardEight from "./Svg/CardEight.jpg";
import CardNine from "./Svg/CardNine.jpg";






export const Images = {
    CardOne,
    CardTwo,
    CardThree,
    CardFour,
    CardFive,
    CardSix,
    CardSeven,
    CardEight,
    CardNine
}